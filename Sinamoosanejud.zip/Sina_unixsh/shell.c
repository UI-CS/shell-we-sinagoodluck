#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_LINE 80 

int main(void) {
    char *args[MAX_LINE/2 + 1]; 
    char input_buffer[MAX_LINE]; 
    char last_command[MAX_LINE] = "";
    int should_run = 1; 
    
    while (should_run) {
        while (waitpid(-1, NULL, WNOHANG) > 0);

        printf("unixsh> ");
        fflush(stdout);
        
        if (fgets(input_buffer, MAX_LINE, stdin) == NULL) {
            break;
        }

        input_buffer[strcspn(input_buffer, "\n")] = 0;

        if (strlen(input_buffer) == 0) {
            continue;
        }

        if (strcmp(input_buffer, "!!") == 0) {
            if (strlen(last_command) == 0) {
                printf("No commands in history.\n");
                continue;
            }
            printf("%s\n", last_command);
            strcpy(input_buffer, last_command);
        } else {
            strcpy(last_command, input_buffer);
        }

        int i = 0;
        int background = 0;
        char *token = strtok(input_buffer, " ");
        while (token != NULL) {
            args[i] = token;
            token = strtok(NULL, " ");
            i++;
        }
        args[i] = NULL; 

        if (i == 0) continue;

        if (i > 0 && strcmp(args[i-1], "&") == 0) {
            background = 1;
            args[i-1] = NULL;
        }

        if (strcmp(args[0], "exit") == 0) {
            should_run = 0;
            continue;
        }

        if (strcmp(args[0], "cd") == 0) {
            if (args[1] == NULL) {
                fprintf(stderr, "unixsh: expected argument to \"cd\"\n");
            } else {
                if (chdir(args[1]) != 0) {
                    perror("unixsh");
                }
            }
            continue;
        }

        if (strcmp(args[0], "pwd") == 0) {
            char cwd[1024];
            if (getcwd(cwd, sizeof(cwd)) != NULL) {
                printf("%s\n", cwd);
            } else {
                perror("getcwd() error");
            }
            continue;
        }

        int pipe_idx = -1;
        for (int j = 0; args[j] != NULL; j++) {
            if (strcmp(args[j], "|") == 0) {
                pipe_idx = j;
                break;
            }
        }

        if (pipe_idx != -1) {
            args[pipe_idx] = NULL;
            char **args2 = &args[pipe_idx + 1];

            int pipefd[2];
            if (pipe(pipefd) == -1) {
                perror("pipe failed");
                continue;
            }

            pid_t p1 = fork();
            if (p1 < 0) {
                perror("fork failed");
                return 1;
            }

            if (p1 == 0) {
                close(pipefd[0]);
                dup2(pipefd[1], STDOUT_FILENO);
                close(pipefd[1]);
                if (execvp(args[0], args) == -1) {
                    printf("Command not found: %s\n", args[0]);
                    exit(1);
                }
            }

            pid_t p2 = fork();
            if (p2 < 0) {
                perror("fork failed");
                return 1;
            }

            if (p2 == 0) {
                close(pipefd[1]);
                dup2(pipefd[0], STDIN_FILENO);
                close(pipefd[0]);
                if (execvp(args2[0], args2) == -1) {
                    printf("Command not found: %s\n", args2[0]);
                    exit(1);
                }
            }

            close(pipefd[0]);
            close(pipefd[1]);
            wait(NULL);
            wait(NULL);
            continue;
        }

        pid_t pid = fork();

        if (pid < 0) {
            perror("Fork failed");
            return 1;
        } 
        else if (pid == 0) {
            if (execvp(args[0], args) == -1) {
                printf("Command not found: %s\n", args[0]);
            }
            exit(1);
        } 
        else {
            if (background == 0) {
                wait(NULL);
            } else {
                printf("[Running in background] process %d\n", pid);
            }
        }
    }
    
    return 0;
}