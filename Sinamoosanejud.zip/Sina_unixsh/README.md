# Unix Shell Implementation & Parallel Computing Project

This project is a custom implementation of a Unix Shell in **C**, developed as part of the Operating Systems course. It demonstrates core OS concepts such as process creation (`fork`, `exec`), process synchronization (`wait`), inter-process communication (pipes), and multithreading.

## 🚀 Features

### 1. Unix Shell (`shell.c`)
A fully functional command-line interface supporting:
- **Basic Command Execution**: Executes standard Unix commands (e.g., `ls`, `ps`, `grep`).
- **Built-in Commands**:
  - `cd`: Change directory.
  - `pwd`: Print working directory.
  - `exit`: Terminate the shell.
- **I/O Redirection (Pipes)**: Supports piping between two commands (e.g., `ls | grep txt`).
- **Background Execution**: Runs processes in the background using `&` (e.g., `sleep 5 &`).
- **History**: Re-executes the last command using `!!`.
- **Zombie Handling**: Automatically reaps background processes to prevent zombie states.

### 2. Parallel Sudoku Validator (`sudoku.c`)
A multithreaded program that validates a 9x9 Sudoku puzzle.
- Uses **11 threads** in parallel:
  - 9 threads for checking 3x3 subgrids.
  - 1 thread for checking all rows.
  - 1 thread for checking all columns.

### 3. Monte Carlo Pi Estimation (`monte_carlo.c`)
A parallel program to estimate the value of **π** using the Monte Carlo method.
- Uses **Pthreads** to generate random points concurrently.
- Thread-safe random number generation using `rand_r`.
- High performance and accuracy using parallel computation.

---

## 🛠️ Installation & Compilation

Ensure you have `gcc` installed (Linux or WSL on Windows).

### 1. Compile the Shell
```bash
gcc shell.c -o shell
```
### 2. Compile Sudoku Validator
```Bash
gcc sudoku.c -o sudoku -pthread
```
### 3. Compile Monte Carlo Estimator
```Bash
gcc monte_carlo.c -o monte_carlo -pthread
```

---

## 📖 Usage Examples
### 1. Running the Shell
Start the custom shell by running the executable:

```Bash
./shell
```

Supported Commands & Features: Once inside the shell (indicated by the unixsh> prompt), you can run standard Unix commands and utilize the implemented features:

```Bash
unixsh> ls -la                # List files with details
unixsh> pwd                   # Print current working directory
unixsh> cd ..                 # Change directory (Built-in command)
unixsh> ls | grep .c          # Pipe: connects output of 'ls' to input of 'grep'
unixsh> sleep 5 &             # Background execution (returns prompt immediately)
unixsh> !!                    # History: re-executes the last command (sleep 5 &)
unixsh> exit                  # Exit the shell
```
### 2. Running Sudoku Validator
This program validates the hardcoded 9x9 Sudoku grid using multithreading.

Command:

``` Bash
./sudoku
```

Expected Output:

``` Plaintext
Sudoku puzzle is valid
```
### 3. Running Monte Carlo Pi Estimation
This program estimates the value of Pi using the Monte Carlo method with parallel threads.

Syntax:

```Bash
./monte_carlo <number_of_threads> <total_points>
```
Example: Run with 4 threads and 10,000,000 points for high accuracy:

```Bash
./monte_carlo 4 10000000
```
Expected Output:

```Plaintext
Estimated Pi: 3.141xxx
```
## 📂 Project Structure
`shell.c`: Source code for the main shell implementation.

`sudoku.c`: Source code for the parallel Sudoku validator.

`monte_carlo.c`: Source code for the Pi estimation program.

`README.md`: Project documentation.