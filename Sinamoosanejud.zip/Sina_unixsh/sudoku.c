#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

int sudoku[9][9] = {
    {6, 2, 4, 5, 3, 9, 1, 8, 7},
    {5, 1, 9, 7, 2, 8, 6, 3, 4},
    {8, 3, 7, 6, 1, 4, 2, 9, 5},
    {1, 4, 3, 8, 6, 5, 7, 2, 9},
    {9, 5, 8, 2, 4, 7, 3, 6, 1},
    {7, 6, 2, 3, 9, 1, 4, 5, 8},
    {3, 7, 1, 9, 5, 6, 8, 4, 2},
    {4, 9, 6, 1, 8, 2, 5, 7, 3},
    {2, 8, 5, 4, 7, 3, 9, 1, 6}
};

int valid[11] = {0};

typedef struct {
    int row;
    int column;
} parameters;

void *check_rows(void *param) {
    for (int i = 0; i < 9; i++) {
        int visited[10] = {0};
        for (int j = 0; j < 9; j++) {
            int val = sudoku[i][j];
            if (visited[val] == 1) pthread_exit(NULL);
            visited[val] = 1;
        }
    }
    valid[9] = 1;
    pthread_exit(NULL);
}

void *check_cols(void *param) {
    for (int i = 0; i < 9; i++) {
        int visited[10] = {0};
        for (int j = 0; j < 9; j++) {
            int val = sudoku[j][i];
            if (visited[val] == 1) pthread_exit(NULL);
            visited[val] = 1;
        }
    }
    valid[10] = 1;
    pthread_exit(NULL);
}

void *check_subgrid(void *param) {
    parameters *data = (parameters *) param;
    int row_start = data->row;
    int col_start = data->column;
    int visited[10] = {0};
    
    int grid_id = (row_start / 3) * 3 + (col_start / 3);

    for (int i = row_start; i < row_start + 3; i++) {
        for (int j = col_start; j < col_start + 3; j++) {
            int val = sudoku[i][j];
            if (visited[val] == 1) pthread_exit(NULL);
            visited[val] = 1;
        }
    }
    valid[grid_id] = 1;
    pthread_exit(NULL);
}

int main() {
    pthread_t threads[11];
    parameters *data[9];

    for (int i = 0; i < 9; i++) {
        data[i] = (parameters *) malloc(sizeof(parameters));
        data[i]->row = (i / 3) * 3;
        data[i]->column = (i % 3) * 3;
        pthread_create(&threads[i], NULL, check_subgrid, data[i]);
    }

    pthread_create(&threads[9], NULL, check_rows, NULL);
    pthread_create(&threads[10], NULL, check_cols, NULL);

    for (int i = 0; i < 11; i++) {
        pthread_join(threads[i], NULL);
    }

    int is_valid = 1;
    for (int i = 0; i < 11; i++) {
        if (valid[i] == 0) {
            is_valid = 0;
            break;
        }
    }

    if (is_valid)
        printf("Sudoku puzzle is valid\n");
    else
        printf("Sudoku puzzle is invalid\n");

    for (int i = 0; i < 9; i++) free(data[i]);
    return 0;
}