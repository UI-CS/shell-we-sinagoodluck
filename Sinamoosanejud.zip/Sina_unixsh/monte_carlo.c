#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

long total_points;
int num_threads;
long points_in_circle = 0;

pthread_mutex_t lock;

void *count_points(void *param) {
    long points_per_thread = total_points / num_threads;
    long local_count = 0;
    unsigned int seed = time(NULL) ^ (unsigned long)pthread_self();

    for (long i = 0; i < points_per_thread; i++) {
        double x = (double)rand_r(&seed) / RAND_MAX * 2.0 - 1.0;
        double y = (double)rand_r(&seed) / RAND_MAX * 2.0 - 1.0;
        
        if (x * x + y * y <= 1.0) {
            local_count++;
        }
    }

    pthread_mutex_lock(&lock);
    points_in_circle += local_count;
    pthread_mutex_unlock(&lock);
    
    pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <num_threads> <total_points>\n", argv[0]);
        return 1;
    }

    num_threads = atoi(argv[1]);
    total_points = atol(argv[2]);

    if (num_threads <= 0 || total_points <= 0) {
        printf("Arguments must be positive integers.\n");
        return 1;
    }

    pthread_t *threads = malloc(num_threads * sizeof(pthread_t));
    pthread_mutex_init(&lock, NULL);

    for (int i = 0; i < num_threads; i++) {
        pthread_create(&threads[i], NULL, count_points, NULL);
    }

    for (int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }

    double pi_estimate = 4.0 * points_in_circle / total_points;
    printf("Estimated Pi: %f\n", pi_estimate);

    pthread_mutex_destroy(&lock);
    free(threads);
    return 0;
}
